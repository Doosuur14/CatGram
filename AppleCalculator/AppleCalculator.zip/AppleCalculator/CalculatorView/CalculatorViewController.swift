//
//  ViewController.swift
//  AppleCalculator
//
//  Created by Faki Doosuur Doris on 07.10.2023.
//

import UIKit

class CalculatorViewController: UIViewController {
    //using MVC approach
    let calculatorModel = CalculatorModel()
    ///Label to display the current result of the calculator
    private lazy var myLabel: UILabel = {
        let someView = UILabel()
        someView.textAlignment = .justified
        someView.textColor = .white
        someView.text = "0"
        someView.font = UIFont.boldSystemFont(ofSize: 36)
        someView.backgroundColor = .systemPink
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    ///variable which is going to label to display current input and the current result.
    private var currentInput: String = ""
    
    ///Button varaibles for digits.
    private lazy var button1: UIButton = {
        let someView = UIButton()
        someView.setTitle("1", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .systemGray5
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button2: UIButton = {
        let someView = UIButton()
        someView.setTitle("2", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button3: UIButton = {
        let someView = UIButton()
        someView.setTitle("3", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button4: UIButton = {
        let someView = UIButton()
        someView.setTitle("4", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button5: UIButton = {
        let someView = UIButton()
        someView.setTitle("5", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button6: UIButton = {
        let someView = UIButton()
        someView.setTitle("6", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button7: UIButton = {
        let someView = UIButton()
        someView.setTitle("7", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button8: UIButton = {
        let someView = UIButton()
        someView.setTitle("8", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button9: UIButton = {
        let someView = UIButton()
        someView.setTitle("9", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var button0: UIButton = {
        let someView = UIButton()
        someView.setTitle("0", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    
    ///Button variables for arithmetic operations.
    private lazy var buttonPlus: UIButton = {
        let someView = UIButton()
        someView.setTitle("+", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonMinus: UIButton = {
        let someView = UIButton()
        someView.setTitleColor(.black, for: .normal)
        someView.setTitle("-", for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonMultiply: UIButton = {
        let someView = UIButton()
        someView.setTitle("*", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonDivide: UIButton = {
        let someView = UIButton()
        someView.setTitle("/", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonClear: UIButton = {
        let someView = UIButton()
        someView.setTitle("AC", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonPoint: UIButton = {
        let someView = UIButton()
        someView.setTitle(".", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonEquals: UIButton = {
        let someView = UIButton()
        someView.setTitle("=", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonPercent: UIButton = {
        let someView = UIButton()
        someView.setTitle("%", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonClearLast: UIButton = {
        let someView = UIButton()
        someView.setTitle("<-", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonPi: UIButton = {
        let someView = UIButton()
        someView.setTitle("π", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonSquareRoot: UIButton = {
        let someView = UIButton()
        someView.setTitle("√", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonCubeRoot: UIButton = {
        let someView = UIButton()
        someView.setTitle("3√", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonParentheses1: UIButton = {
        let someView = UIButton()
        someView.setTitle("(", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonParentheses2: UIButton = {
        let someView = UIButton()
        someView.setTitle(")", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonMemoryStore: UIButton = {
        let someView = UIButton()
        someView.setTitle("M+", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private lazy var buttonMemoryRecall: UIButton = {
        let someView = UIButton()
        someView.setTitle("MR", for: .normal)
        someView.setTitleColor(.black, for: .normal)
        someView.backgroundColor = .white
        someView.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        someView.translatesAutoresizingMaskIntoConstraints = false
        return someView
    }()
    private var memory: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemPink
        
        ///add buttons subview to view
        addSubViews(button0,button1,button2,button3,button4,button5,button6,
                    button7,button8,button9,buttonPlus,buttonClear,buttonMinus,
                    buttonDivide,buttonMultiply,buttonPercent,myLabel,buttonEquals, buttonPoint,buttonClearLast)
        ///Configuration of all autolayout constriants.
        configureUI()
        
    }
    
    ///func will tansistion to  be able to move the calculator from potrait to landscape mode.
    ///Also additonal func setuplayout for landscape t to be able to add extra buttons when in landscape mode.
    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
        super.willTransition(to: newCollection, with: coordinator)
        if UIDevice.current.orientation.isPortrait {
            buttonPi.isHidden = true
            buttonSquareRoot.isHidden = true
            buttonCubeRoot.isHidden = true
            buttonMemoryStore.isHidden = true
            buttonParentheses1.isHidden = true
            buttonParentheses2.isHidden = true
            
            view.layoutIfNeeded()
            
        } else if UIDevice.current.orientation.isLandscape {
            addSubViews(buttonPi, buttonSquareRoot, buttonCubeRoot, buttonMemoryStore, buttonParentheses1, buttonParentheses2)
            updateLandscapeLayout()
        }
    }

   
    
    func buttonForRow(_ row: Int, _ column: Int) -> UIButton {
        let buttons = [
            [buttonClear, buttonPoint, buttonPercent, buttonPlus, buttonPi],
            [button7, button8, button9, buttonMinus, buttonSquareRoot],
            [button4, button5, button6, buttonDivide, buttonCubeRoot],
            [button1, button2, button3, buttonMultiply,buttonMemoryStore ],
            [button0, buttonClearLast, buttonEquals, buttonParentheses1, buttonParentheses2 ]
        ]
        return buttons[row][column]
    }
    
    
    func updateLandscapeLayout() {
        
        let parenthesesButton = [buttonParentheses1 ,buttonParentheses2]
        // Clear existing constraints
        view.removeConstraints(view.constraints)

        let buttonSpacing: CGFloat = 5
        let numberOfRows = 5 // Increase the number of rows for landscape mode
        let numberOfColumns = 5 // Increase the number of columns for landscape mode

        // Calculate button sizes for landscape orientation
        let buttonWidth = (view.bounds.width - CGFloat(numberOfColumns - 1) * buttonSpacing) / CGFloat(numberOfColumns)
        let buttonHeight = (view.bounds.height - CGFloat(numberOfRows - 1) * buttonSpacing) / CGFloat(numberOfRows)

        // Define constraints for myLabel
        let labelConstraints = [
            myLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            myLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            myLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            myLabel.heightAnchor.constraint(equalToConstant: 100)
        ]

        // Define constraints for buttons in landscape orientation
        var buttonConstraints: [NSLayoutConstraint] = []

        for row in 0..<numberOfRows {
            for column in 0..<numberOfColumns {
                let button = buttonForRow(row, column)
                let leadingAnchor: NSLayoutXAxisAnchor
                let topAnchor: NSLayoutYAxisAnchor

                if column == 0 {
                    leadingAnchor = view.leadingAnchor
                } else {
                    leadingAnchor = buttonForRow(row, column - 1).trailingAnchor
                }

                if row == 0 {
                    topAnchor = myLabel.bottomAnchor
                } else {
                    topAnchor = buttonForRow(row - 1, column).bottomAnchor
                }

                buttonConstraints += [
                    button.leadingAnchor.constraint(equalTo: leadingAnchor, constant: buttonSpacing),
                    button.topAnchor.constraint(equalTo: topAnchor, constant: buttonSpacing),
                    button.widthAnchor.constraint(equalToConstant: buttonWidth),
                    button.heightAnchor.constraint(equalToConstant: buttonHeight)
                ]
            }
        }
        
        
        buttonPi.addTarget(self, action: #selector(piButtonTapped), for: .touchUpInside)
        buttonMemoryStore.addTarget(self, action: #selector(memoryAddButtonTapped), for: .touchUpInside)
        buttonSquareRoot.addTarget(self, action: #selector(squareRootButtonTapped), for: .touchUpInside)
        buttonCubeRoot.addTarget(self, action: #selector(cubeRootButtonTapped), for: .touchUpInside)
        
        for button in parenthesesButton {
            button.addTarget(self, action: #selector((operationButtonTapped(_ :))), for: .touchUpInside)
        }
        // Activate constraints
        NSLayoutConstraint.activate(labelConstraints + buttonConstraints)
        view.layoutIfNeeded()
    }

    
    
    func configureUI() {
        let digitsButtons: [UIButton] = [ buttonClear, buttonPoint, buttonPercent,
                                          button7, button8, button9, button4, button5,
                                          button6, button1, button2, button3]
        
        let operationButtons: [UIButton] = [buttonPlus, buttonMinus,  buttonDivide, buttonMultiply]
        
        let buttonSpacing = CGFloat(5)
        let buttonSize: CGFloat = (view.bounds.width - 4 * buttonSpacing) / 4.0 - 2 * buttonSpacing
        
        ///empty array of layoutconstriants.
        var constraints: [NSLayoutConstraint] = []
        
        /// Constraints for my label
        constraints += [
            myLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            myLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            myLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            myLabel.heightAnchor.constraint(equalToConstant: 100),
            
            button0.heightAnchor.constraint(equalToConstant: buttonSize),
            button0.widthAnchor.constraint(equalToConstant: buttonSize * 2),
            button0.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            button0.topAnchor.constraint(equalTo: buttonMultiply.bottomAnchor, constant: 5),
            
            buttonEquals.heightAnchor.constraint(equalToConstant: buttonSize),
            buttonEquals.widthAnchor.constraint(equalToConstant: buttonSize),
            buttonEquals.leadingAnchor.constraint(equalTo: buttonClearLast.trailingAnchor, constant: 7),
            buttonEquals.topAnchor.constraint(equalTo: buttonMultiply.bottomAnchor, constant: 5),
            
            buttonClearLast.heightAnchor.constraint(equalToConstant: buttonSize),
            buttonClearLast.widthAnchor.constraint(equalToConstant: buttonSize ),
            buttonClearLast.leadingAnchor.constraint(equalTo: button0.trailingAnchor, constant: 6),
            buttonClearLast.topAnchor.constraint(equalTo: button3.bottomAnchor, constant: 5),
        ]
        
        for (index, button) in digitsButtons.enumerated() {
            constraints += [
                button.heightAnchor.constraint(equalToConstant: buttonSize),
                button.widthAnchor.constraint(equalToConstant: buttonSize),
                button.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant:buttonSpacing + CGFloat(index % 3) * (buttonSize + buttonSpacing)),
                button.topAnchor.constraint(equalTo: myLabel.bottomAnchor, constant: buttonSpacing + CGFloat(index / 3) * (buttonSize + buttonSpacing)),
            ]
        }
        
        for (index, button) in operationButtons.enumerated() {
            constraints += [
                button.heightAnchor.constraint(equalToConstant: buttonSize),
                button.widthAnchor.constraint(equalToConstant: buttonSize),
                button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
                button.topAnchor.constraint(equalTo: myLabel.bottomAnchor, constant: buttonSpacing + CGFloat(index) * (buttonSize + buttonSpacing))
            ]
        }
        
        ///Adding targets to buttons with number variables.
        for buttons in digitsButtons {
            buttons.addTarget(self, action: #selector(digitButtonTapped(_:)), for: .touchUpInside)
        }
        for buttons in operationButtons {
            buttons.addTarget(self, action: #selector(operationButtonTapped(_:)), for: .touchUpInside)
        }
        

        button0.addTarget(self, action: #selector(zeroButtonTapped), for: .touchUpInside)
        buttonEquals.addTarget(self, action: #selector(equalsButtonTapped), for: .touchUpInside)
        buttonClearLast.addTarget(self, action: #selector(clearLastNumberButtonTapped), for: .touchUpInside)
      

        NSLayoutConstraint.activate(constraints)
    }
    
    
    @objc func digitButtonTapped(_ sender: UIButton) {
        print("button tapped!")
        if let digit = sender.titleLabel?.text {
            if digit == "AC" {
                currentInput = "0"
                calculatorModel.clear()
            } else if digit == "%" {
                if Double(currentInput) != nil {
                    let res = (Double(currentInput)! / 100)
                    currentInput = String(res)
                }
            } else if digit == "."{
                if !currentInput.contains(".") {
                    calculatorModel.isDecimalInput = true
                    currentInput += digit
                    calculatorModel.inputNumber(Double(digit) ?? 0.0)
                }
            } else {
                currentInput += digit
                calculatorModel.inputNumber(Double(digit) ?? 0.0)
            }
            update()
            
        }
    }
    
    @objc func operationButtonTapped(_ sender: UIButton) {
        if let operatorSign = sender.titleLabel?.text {
            if operatorSign == "(" {
                currentInput += "("
            } else if operatorSign == ")" {
                currentInput += ")"
            } else {
                calculatorModel.inputOperator(operatorSign)
                currentInput = "0"
                update()
            }
        }
      }
    @objc func zeroButtonTapped(_ sender: UIButton) {
        if currentInput != "0"{
            currentInput += "0"
        }
        update()
    }
    @objc func equalsButtonTapped() {
        if let result = calculatorModel.performOperation() {
                currentInput = String(format: "%.2f", result)
                calculatorModel.clear()
            } else {
                currentInput = "Error"
            }
            update()
    }
    @objc func piButtonTapped() {
        currentInput = "\(Double.pi)"
        update()
    }
    @objc func squareRootButtonTapped() {
        if let number = Double(currentInput), number >= 0 {
            let squareRoot = sqrt(number)
            currentInput = "\(squareRoot)"
        } else {
            ///if number entered is negative or invalid.
            currentInput = "Error"
        }
        update()
    }
    @objc func cubeRootButtonTapped() {
        if let number = Double(currentInput) {
            let cubeRoot = pow(number, 1.0/3.0)
            currentInput = "\(cubeRoot)"
        } else {
            ///if number entered is negative or invalid.
            currentInput = "Error"
        }
        update()
    }

    @objc func clearLastNumberButtonTapped(_ sender: UIButton) {
        print("tapped")
        if !currentInput.isEmpty {
             currentInput.removeLast()
            update()
        }
        
    }
    
    @objc func memoryAddButtonTapped() {
        if let number = Double(currentInput) {
            ///Store the current input  in memory
            memory = number
        }
        update()
    }

//    @objc func memoryRecallButtonTapped() {
//        if let valueInMemory = memory {
//            ///get the current input from memory and display it on the screen
//            currentInput = "\(valueInMemory)"
//        } else {
//            // Handle the case where there's nothing in memory
//            currentInput = "0"
//        }
//        update()
//    }
        ///Function to update myLabel to either show the result of the last calculation or what the user has typed if he has.
        func update() {
            myLabel.text = currentInput.isEmpty ? "\(calculatorModel.getResult())": currentInput
        }
        
    }

extension CalculatorViewController {
    private func addSubViews(_ subviews: UIView...) {
        subviews.forEach {view.addSubview($0)}
    }
}
