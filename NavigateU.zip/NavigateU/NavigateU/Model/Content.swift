//
//  Content.swift
//  NavigateU
//
//  Created by Faki Doosuur Doris on 07.04.2024.
//

import Foundation
import UIKit

 struct Content {
     let photo: UIImage?
     let title: String
     let subTitle: String
}
