//
//  Profile.swift
//  NavigateU
//
//  Created by Faki Doosuur Doris on 15.04.2024.
//

import Foundation
import UIKit

struct Profile {
    let photo: UIImage?
    let lable: String
    let arrow: UIImage?
}
