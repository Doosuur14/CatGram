//
//  Model.swift
//  TimerApp
//
//  Created by Faki Doosuur Doris on 16.04.2024.
//

import Foundation
import UIKit

struct Task {
    let task: String
    let timer: String
}
