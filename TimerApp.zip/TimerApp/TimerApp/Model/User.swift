//
//  User.swift
//  TimerApp
//
//  Created by Faki Doosuur Doris on 16.04.2024.
//

import Foundation

import Foundation

struct User {
    let email: String
    let password: String
    
}
