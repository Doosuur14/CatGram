//
//  MainTableViewCell.swift
//  TimerApp
//
//  Created by Faki Doosuur Doris on 16.04.2024.
//

import UIKit

class MainTableViewCell: UITableViewCell {

   
}
