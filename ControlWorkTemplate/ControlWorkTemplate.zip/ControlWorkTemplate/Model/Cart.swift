//
//  Cart.swift
//  ControlWorkTemplate
//
//  Created by Faki Doosuur Doris on 10.10.2023.
//

import Foundation

struct CartItem: Hashable {
    let car: Car
    var quantity: Int
}

class Cart {
    var items: [CartItem] = []

    // Add a car to the cart
    func addCar(_ car: Car) {
        if let index = items.firstIndex(where: { $0.car == car }) {
            items[index].quantity += 1
        } else {
            let newItem = CartItem(car: car, quantity: 1)
            items.append(newItem)
        }
    }

    // Remove a car from the cart
    func removeCar(_ car: Car) {
        if let index = items.firstIndex(where: { $0.car == car }) {
            if items[index].quantity > 1 {
                items[index].quantity -= 1
            } else {
                items.remove(at: index)
            }
        }
    }

    // Get the total cost of items in the cart
    func getTotalCost() -> Double {
        let totalCost = items.reduce(0.0) { result, item in
            if let carPrice = Double(item.car.carprice) {
                return result + carPrice * Double(item.quantity)
            }
            return result
        }
        return totalCost
    }

    // Get the items in the cart
    func getItems() -> [CartItem] {
        return items
    }

    // Clear the cart
    func clearCart() {
        items.removeAll()
    }
}
